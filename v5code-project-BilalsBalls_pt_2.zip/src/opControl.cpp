#include "vex.h"
#include <cmath>
#include "main.h"
#include "robot-config.h"

void joystickCont()
{
   int left,right;
 
  
    left = Controller1.Axis3.value() * 0.11;
    
 
   
  
    right = Controller1.Axis2.value() * 0.095 ;  

 

  frontL.spin(forward,(left), volt);
  middleL.spin(forward,(left),volt);
  backL.spin(forward,(left), volt);
  frontR.spin(forward,(right), volt);
  middleR.spin(forward,(right), volt);
  backR.spin(forward,(right), volt);  

  frontL.setStopping(brakeType::coast);
  middleL.setStopping(brakeType::coast);
  backL.setStopping(brakeType::coast);
  frontR.setStopping(brakeType::coast);
  middleR.setStopping(brakeType::coast);
  backR.setStopping(brakeType::coast);
}


void intakeCont()
{
  
  if(Controller1.ButtonR1.pressing()){
    intake.spin(reverse,100,percent);
    cata.spin(reverse, 100, percent);
  }
  else if(Controller1.ButtonR2.pressing())
  {
    intake.spin(forward,100,percent);
    cata.spin(forward, 100, percent);
  }
  else{
    intake.stop(brakeType::coast);
    cata.stop(brakeType::coast);
  }
}

void cataCont()
{
  //manual shooting 
  /*
  if(Controller1.ButtonL1.pressing())
    cata.spin(forward,100,percent);
  else
    cata.stop(brakeType::brake   );
    */

  //automatic shooting
  /*
    if(Controller1.ButtonL2.pressing())
  {
    cata.spin(forward, 100, percent);
    if(cataLimit.pressing())
    {
      //task::sleep(40);
      cata.stop(brakeType::brake);
    }
    if(ballDetector.value(analogUnits::mV) <= 1700)
    {
      cata.spin(forward,100,percent);

    }
  }
  */
}


bool wingToggle = false;
bool wingLatch = false;

bool wingToggle1 = false;
bool wingLatch1 = false;
bool wingBoth = false;
bool wingR = false;
bool wingL = false;
bool hangToggle = false;

void wingsCont()
{
     if(Controller1.ButtonL1.pressing())
   {

    if(!wingLatch)
    {
    wingToggle = !wingToggle;
    wingLatch = true;
    }

    }
  else {
  wingLatch = false;
  wings.close();
  wingsR.close();
  }

  if(wingToggle)
  {
    wings.open();
    wingsR.open();
  }


   if(Controller1.ButtonL2.pressing())
   {

    if(!wingLatch1)
    {
    wingToggle1 = !wingToggle1;
    wingLatch1 = true;
    }

    }
  else {
  wingLatch1 = false;
    wingsV.close();
  }

  if(wingToggle1)
  {
    wingsV.open();
  }

}

void cataToggle(){
  bool toggleEnabled = false; // two-choice toggle, so we use bool
  bool buttonPressed = false; // IGNORE, logic variable

  while (true){
    
    bool buttonA = Controller1.ButtonA.pressing();
    // Toggle Logic
    if (buttonA && !buttonPressed){
      buttonPressed = true; 
      toggleEnabled = !toggleEnabled;
    }
    else if (!buttonA) buttonPressed = false;

    ////////////////////////////////////////////////////////////////////
    // Cata control
    if(toggleEnabled){
      // Do another thing
      spinUpReverse(true);
    }
    else{
      spinUpReverse(false);
    }
  }
}
