#include "vex.h"
#include <cmath>
#include "main.h"
#include "robot-config.h"

void joystickCont()
{
   int left,right;
 
  
    left = Controller1.Axis3.value() * 0.11;
    
 
   
  
    right = Controller1.Axis2.value() * 0.095 ;  

 

  frontL.spin(forward,(left), volt);
  middleL.spin(forward,(left),volt);
  backL.spin(forward,(left), volt);
  frontR.spin(forward,(right), volt);
  middleR.spin(forward,(right), volt);
  backR.spin(forward,(right), volt);  

  frontL.setStopping(brakeType::coast);
  middleL.setStopping(brakeType::coast);
  backL.setStopping(brakeType::coast);
  frontR.setStopping(brakeType::coast);
  middleR.setStopping(brakeType::coast);
  backR.setStopping(brakeType::coast);
}


void intakeCont()
{
  
  if(Controller1.ButtonR1.pressing()){
    intake.spin(reverse,100,percent);
    cata.spin(reverse, 100, percent);
  }
  else if(Controller1.ButtonR2.pressing())
  {
    intake.spin(forward,100,percent);
    cata.spin(forward, 100, percent);
  }
  else{
    intake.stop(brakeType::coast);
    cata.stop(brakeType::coast);
  }
}

void cataCont()
{
  //manual shooting 
  /*
  if(Controller1.ButtonL1.pressing())
    cata.spin(forward,100,percent);
  else
    cata.stop(brakeType::brake   );
    */

  //automatic shooting
  /*
    if(Controller1.ButtonL2.pressing())
  {
    cata.spin(forward, 100, percent);
    if(cataLimit.pressing())
    {
      //task::sleep(40);
      cata.stop(brakeType::brake);
    }
    if(ballDetector.value(analogUnits::mV) <= 1700)
    {
      cata.spin(forward,100,percent);

    }
  }
  */
}

bool autoToggle = false;
bool autoLatch = false;

void autoCata()

{
  /*
if(Controller1.ButtonL2.pressing())
   {

    if(!autoLatch)
    {
    autoToggle = !autoToggle;
    autoLatch = true;
    }

    }
  else {
  autoLatch = false;
  //wings.close();
  }

  if(autoToggle)
  {
    //wings.open();
    cata.spin(forward, 100, percent);
    if(cataLimit.pressing())
    {
      //task::sleep(40);
      cata.stop(brakeType::brake);
    }
    if(ballDetector.value(analogUnits::mV) <= 2700)
    {
      cata.spin(forward,100,percent);

    }
  }
  */
}

bool wingToggle = false;
bool wingLatch = false;

bool wingToggle1 = false;
bool wingLatch1 = false;
bool wingBoth = false;
bool wingR = false;
bool wingL = false;
bool hangToggle = false;

void wingsCont()
{
     if(Controller1.ButtonL1.pressing())
   {

    if(!wingLatch)
    {
    wingToggle = !wingToggle;
    wingLatch = true;
    }

    }
  else {
  wingLatch = false;
  wings.close();
  wingsR.close();
  }

  if(wingToggle)
  {
    wings.open();
    wingsR.open();
  }


   if(Controller1.ButtonL2.pressing())
   {

    if(!wingLatch1)
    {
    wingToggle1 = !wingToggle1;
    wingLatch1 = true;
    }

    }
  else {
  wingLatch1 = false;
    wingsV.close();
  }

  if(wingToggle1)
  {
    wingsV.open();
  }

}

void hangCont(){
   bool buttonPressed3 = false;
   bool buttonL2 = Controller1.ButtonL2.pressing();
   if (!buttonPressed3 && buttonL2 ){
     buttonPressed3 = true;
     hang.open();
     hang1.open();
   }
   else if (!buttonL2){
      buttonPressed3 = false;
      hang.close();
      hang.close();
   }
}


bool liftToggle = false;
bool liftLatch = false;

/*void autoLift()
{
if(Controller1.ButtonX.pressing())
   {

    if(!liftLatch)
    {
    liftToggle = !liftToggle;
    liftLatch = true;
    }

    }
  else {
  liftLatch = false;
  //pullUp.close();
  //assist.close();

  pullUp.close();
    assist.close();
  }

  if(liftToggle)
  {
    pullUp.open();
  assist.open();
  }
}
*/









/*
bool clampToggle = false;
bool latch = false;

void mogoClampControl()
{
   if(Controller1.ButtonLeft.pressing())
   {

    if(!latch)
    {
    clampToggle = !clampToggle;
    latch = true;
    }

    }
  else {
  latch = false;
  clamp.open();
  }

  if(clampToggle)
  {
    clamp.close();
  }
}

*/