using namespace vex;


extern brain Brain;
extern controller Controller1;
extern motor frontL;
extern motor middleL;
extern motor backL;
extern motor frontR;
extern motor middleR;
extern motor backR;
extern motor intake;
extern motor cata;
extern inertial iner;
extern pneumatics wings;
extern pneumatics wingsR;
extern pneumatics hang;
extern pneumatics hang1;

extern rotation cataSensor;
/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 
 *
 * This should be called at the start of your int main function.
 */
void vexcodeInit(void);
