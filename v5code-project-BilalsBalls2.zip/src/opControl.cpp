#include "vex.h"
#include <cmath>
#include "main.h"
#include "robot-config.h"

void joystickCont()
{
   int left,right;
 
  
    left = Controller1.Axis3.value() * 0.11;
    
 
   
  
    right = Controller1.Axis2.value() * 0.095 ;  

 

  frontL.spin(forward,(left), volt);
  middleL.spin(forward,(left),volt);
  backL.spin(forward,(left), volt);
  frontR.spin(forward,(right), volt);
  middleR.spin(forward,(right), volt);
  backR.spin(forward,(right), volt);  

  frontL.setStopping(brakeType::coast);
  middleL.setStopping(brakeType::coast);
  backL.setStopping(brakeType::coast);
  frontR.setStopping(brakeType::coast);
  middleR.setStopping(brakeType::coast);
  backR.setStopping(brakeType::coast);
}

void intakeCont()
{
  if(Controller1.ButtonR1.pressing()){
    intake.spin(reverse,100,percent);
    cata.spin(reverse, 100, percent);
  }
  else if(Controller1.ButtonR2.pressing())
  {
    intake.spin(forward,100,percent);
    cata.spin(forward, 100, percent);
  }
  else{
    intake.stop(brakeType::coast);
    cata.stop(brakeType::coast);
  }
}

void cataCont()
{
  //manual shooting 
  /*
  if(Controller1.ButtonL1.pressing())
    cata.spin(forward,100,percent);
  else
    cata.stop(brakeType::brake   );
    */

  //automatic shooting
  /*
    if(Controller1.ButtonL2.pressing())
  {
    cata.spin(forward, 100, percent);
    if(cataLimit.pressing())
    {
      //task::sleep(40);
      cata.stop(brakeType::brake);
    }
    if(ballDetector.value(analogUnits::mV) <= 1700)
    {
      cata.spin(forward,100,percent);

    }
  }
  */
}

bool autoToggle = false;
bool autoLatch = false;

void autoCata()

{
  /*
if(Controller1.ButtonL2.pressing())
   {

    if(!autoLatch)
    {
    autoToggle = !autoToggle;
    autoLatch = true;
    }

    }
  else {
  autoLatch = false;
  //wings.close();
  }

  if(autoToggle)
  {
    //wings.open();
    cata.spin(forward, 100, percent);
    if(cataLimit.pressing())
    {
      //task::sleep(40);
      cata.stop(brakeType::brake);
    }
    if(ballDetector.value(analogUnits::mV) <= 2700)
    {
      cata.spin(forward,100,percent);

    }
  }
  */
}

bool wingToggle = false;
bool wingLatch = false;
bool wingBoth = false;
bool wingR = false;
bool wingL = false;
bool hangToggle = false;

void wingsCont()
{
if(Controller1.ButtonLeft.pressing())
   {
     wingL = !wingL;
    
    
}
if (Controller1.ButtonRight.pressing()){
  wingR = !wingR;
}
if (Controller1.ButtonUp.pressing()){
  wingL = !wingL;
  wingR = !wingR;
}

if (wingL){
   wings.open();
}
else {
  wings.close();
}
if (wingR){
  wingsR.open();
}
else {
  wingsR.close();
}
}
void hangCont(){
  if (Controller1.ButtonL2.pressing()){
    hangToggle = !hangToggle;
  }
  if (hangToggle){
    hang.open();
    hang1.open();
  }
  else {
    hang.close();
    hang1.close();
  }
}


bool liftToggle = false;
bool liftLatch = false;

/*void autoLift()
{
if(Controller1.ButtonX.pressing())
   {

    if(!liftLatch)
    {
    liftToggle = !liftToggle;
    liftLatch = true;
    }

    }
  else {
  liftLatch = false;
  //pullUp.close();
  //assist.close();

  pullUp.close();
    assist.close();
  }

  if(liftToggle)
  {
    pullUp.open();
  assist.open();
  }
}
*/









/*
bool clampToggle = false;
bool latch = false;

void mogoClampControl()
{
   if(Controller1.ButtonLeft.pressing())
   {

    if(!latch)
    {
    clampToggle = !clampToggle;
    latch = true;
    }

    }
  else {
  latch = false;
  clamp.open();
  }

  if(clampToggle)
  {
    clamp.close();
  }
}

*/